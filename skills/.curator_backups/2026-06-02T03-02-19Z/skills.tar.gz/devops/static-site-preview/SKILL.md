---
name: static-site-preview
description: "Deploy static HTML/CSS/JS sites for user preview. GitHub Pages as default, Netlify as fallback."
version: 1.0.0
author: Hermes Agent
license: MIT
platforms: [linux]
metadata:
  hermes:
    tags: [deployment, static-site, github-pages, preview, netlify]
    related_skills: [github-auth, github-repo-management]
---

# Static Site Preview Deployment

Deploy HTML/CSS/JS prototypes and creative work so the user can view them in a browser.

## Trigger

Use this skill when the user says anything like:
- "show me"
- "deploy this"
- "host it"
- "make it live"
- "where can I see this"
- "I want a preview"
- "a place to deploy concepts"

## Decision Tree

```
Is gh CLI authenticated?
├── YES → Use GitHub Pages (fastest, no extra tokens)
│         └── Build → git init → commit → gh repo create --public --source=. --push
│             → API call to enable Pages → live at leegordo.github.io/<repo>
└── NO  → Can we authenticate gh quickly?
          ├── YES → GitHub Pages
          └── NO  → Try Netlify (if CLI installed + token has site scope)
```

**Default: GitHub Pages.** The user explicitly prefers "whatever is easiest." GitHub Pages wins because:
- No extra auth if `gh` is already logged in
- No build config, no `netlify.toml`
- One API call to enable, then automatic deploys on push
- URL is predictable: `https://leegordo.github.io/<repo-name>/`

## Method 1: GitHub Pages (Recommended)

### Prerequisites
- `gh` CLI authenticated (see `github-auth` skill)
- Repo contains an `index.html` at root

### Steps

```bash
# 1. Build/create the site locally
cd /root/my-project
# ... create index.html and assets ...

# 2. Initialize and push
git init
git add .
git commit -m "feat: initial site"
git branch -m main

# 3. Create public repo and push
gh repo create my-project --public --source=. --push

# 4. Enable GitHub Pages via API
cat <<'EOF' > /tmp/pages.json
{
  "source": {
    "branch": "main",
    "path": "/"
  }
}
EOF

curl -s -X POST \
  -H "Authorization: token $(gh auth token)" \
  -H "Accept: application/vnd.github+json" \
  -H "X-GitHub-Api-Version: 2022-11-28" \
  https://api.github.com/repos/leegordo/my-project/pages \
  -d @/tmp/pages.json
```

### Verification

```bash
# Check if site is live (may take 30-60s after enable)
curl -s -I https://leegordo.github.io/my-project/ | head -1
# Expect: HTTP/2 200
```

### Updating

After the initial setup, any push to `main` auto-deploys:

```bash
git add .
git commit -m "update"
git push
```

## Method 2: Netlify (Fallback)

Only use if GitHub Pages is unavailable AND Netlify CLI is already installed with a working token.

### Prerequisites
- `netlify-cli` installed globally: `npm install -g netlify-cli`
- Token with site-management scope (not just status-read scope)

### Steps

```bash
# Authenticate
export NETLIFY_AUTH_TOKEN="<token>"
netlify status  # Should show user, not "Unauthorized"

# Deploy
cd /root/my-project
netlify deploy --prod --dir .
```

### Pitfall: Token Scope

If `netlify status` works but `netlify deploy` or `netlify sites:create` returns:
- `JSONHTTPError: Unauthorized`
- `Error: No teams available`

The token lacks site-management scope. **Do not debug further.** Pivot to GitHub Pages immediately. The user would need to regenerate the PAT at https://app.netlify.com/user/applications/personal with broader scope.

## Method 3: Raw VPS Serve (Emergency Only)

If neither GitHub Pages nor Netlify works, serve locally and expose via the VPS IP:

```bash
cd /root/my-project
python3 -m http.server 8080 --bind 0.0.0.0 &
# User accesses via http://<vps-ip>:8080/
```

**This is emergency-only.** Users with an established GitHub Pages workflow find VPS IP previews frustrating — "why are we hosting on a random IP?" Always prefer pushing to the repo they already own.

**When to use VPS preview:**
- GitHub auth is completely broken AND cannot be fixed in-session
- User explicitly asks for a temporary preview before committing
- Firewall/network issues block all other methods

**When NOT to use VPS preview:**
- User mentions an existing GitHub Pages site (e.g., "our 0xcreative pages site")
- Repo already exists and just needs updated content
- `gh` CLI is authenticated and working

**Firewall note:** If using VPS preview, ensure the port is open:
```bash
ufw allow 8080/tcp
```

## File Structure Convention

For predictable deployment, use this structure:

```
my-project/
├── index.html          # Entry point (required)
├── style.css           # Or inline styles
├── script.js           # Or inline scripts
└── assets/             # Images, fonts, etc.
```

Single-file HTML (`index.html` with inline CSS/JS) is preferred for prototypes — zero build step, one file to track.

## Pitfalls

| Problem | Cause | Fix |
|---------|-------|-----|
| Pages returns 404 | Build hasn't finished | Wait 30-60s, retry |
| Pages returns 404 persistently | Repo is private | GitHub Pages requires public repo for free tier. **Workaround:** Use a separate public repo for Pages (e.g., `username.github.io` or a dedicated public repo) while keeping source code in the private repo. |
| `gh repo create` fails | Not authenticated | Run `gh auth status`, re-auth if needed |
| Netlify "Unauthorized" | Token scope too narrow | Pivot to GitHub Pages |
| Netlify "No teams available" | Token not associated with team | Pivot to GitHub Pages |
| CSS/JS not loading | Relative path issues | Use `./style.css` not `/style.css` for subpath hosting |

## Notes

- **Potential overlap:** The `remote-static-preview` skill may cover similar territory. If both exist, consider consolidating.
- The user (Lee) explicitly prefers the easiest path. Do not present multiple options unless asked. Default to GitHub Pages, mention the URL, and move on.
