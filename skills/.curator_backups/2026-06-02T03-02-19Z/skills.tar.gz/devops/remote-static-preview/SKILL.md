---
name: remote-static-preview
description: "Expose static HTML/CSS/JS previews from a remote VPS so users can review them from anywhere. Covers directory serving, firewall rules, port binding, and deploy-to-Netlify fallback."
version: 1.0.0
author: Hermes Agent
license: MIT
platforms: [linux]
metadata:
  hermes:
    tags: [preview, web, vps, deployment, review]
    related_skills: [subagent-driven-development, claude-design, excalidraw]
---

# Remote Static Preview

## Overview

When building visual designs, HTML mockups, or static prototypes on a remote VPS, users need to view them in a real browser. The default `python3 -m http.server` binds to `127.0.0.1` (localhost), which is unreachable from outside the VPS. This skill covers the full path from files-on-disk to user-visible URLs.

**Core mistake:** Serving on `127.0.0.1` and not opening the firewall. Both are needed.

**Three approaches, simplest first:**
1. **Direct VPS serve** — bind to `0.0.0.0`, open firewall, give user the public IP + port
2. **Tailscale serve** — if user is on Tailscale, serve via `tailscale serve` for a stable hostname + HTTPS
3. **Netlify deploy** — drag-and-drop or CLI deploy for production-grade HTTPS + shareable URL

## The Complete Checklist

### Step 1: Bind to `0.0.0.0`, not `127.0.0.1`

```bash
# WRONG — localhost only, unreachable externally
python3 -m http.server 8000

# RIGHT — listen on all interfaces
python3 -m http.server 8000 --bind 0.0.0.0
```

When using `terminal(background=true)`, the command should be:
```bash
python3 -m http.server 8000 --bind 0.0.0.0
```
Do NOT wrap with `nohup` or shell backgrounding — Hermes manages lifecycle better via `process()`.

### Step 2: Open the Firewall

Check current rules:
```bash
ufw status
```

Open preview ports (one-liner for multiple ports):
```bash
ufw allow 8000/tcp && ufw allow 8001/tcp && ufw allow 8002/tcp
```

**Pitfall:** Most VPS providers (Hetzner, DigitalOcean, Vultr) ship with `ufw` active on 22/80/443 only. Non-standard ports (8000+) are blocked by default. *Always verify after opening*:
```bash
ss -tlnp | grep 8000
```

### Step 3: Get the Public IP

```bash
curl -s icanhazip.com
# or
curl -s ifconfig.me
```

Also check network interfaces for dual-stack (IPv4 + IPv6):
```bash
ip addr show | grep "scope global"
```

**Pitfall:** IPv6-only ISPs or CGNAT IPv4 may make `icanhazip.com` return nothing useful. If the user is on Tailscale, prefer the Tailnet IP (e.g., `100.x.x.x`) since it's always reachable regardless of upstream network shape.

### Step 4: Verify End-to-End

From the VPS itself, confirm the server responds on its *own* public IP:
```bash
curl -s -o /dev/null -w "%{http_code}" http://<PUBLIC_IP>:8000/
```

If this returns `200`, the serve + firewall combo is working. If `Connection refused`, the server isn't bound or the port is firewalled. If `403`, check directory permissions.

### Step 5: Give the User the Right URL

Present the URL clearly:

```
Your preview is live at:
http://187.77.9.15:8000/
```

If IPv6 is available, include it as a fallback:
```
IPv6: http://[2a02:4780:4:5e9c::1]:8000/
```

If the user is on Tailscale, use the Tailnet IP — it's private and encrypted:
```
Tailscale: http://100.84.76.9:8000/
```

## Tailscale Serve (Preferred When Available)

If the user has Tailscale running (`tailscale status` shows connected), use `tailscale serve` instead of raw ports:

```bash
# Serve a directory
nohup tailscale serve --bg --set-path=/preview1 /tmp/portfolio-v1-editorial &
```

Benefits:
- HTTPS automatically via Let's Encrypt
- No firewall rules needed (tailnet is encrypted overlay)
- Stable hostname: `https://<machine-name>.<tailnet-name>.ts.net/preview1`
- Works through CGNAT and restrictive ISPs

Verify:
```bash
tailscale serve status
```

## Netlify Deploy (When Ports Are Blocked)

If the user's network blocks non-standard HTTP ports, or you need a permanent shareable URL:

### Via Netlify CLI

**Headless server auth (no browser):**

On a headless VPS, `netlify login` can't open a browser. If the user provides a personal access token (`nfp_...`), authenticate and verify immediately:

```bash
# Install if needed
npm install -g netlify-cli

# Auth with the provided token
NETLIFY_AUTH_TOKEN=<token> netlify login

# Verify — should list the user's sites
netlify sites:list
```

**Pitfall:** Do NOT store the token in the skill or memory. It is session-scoped. If auth fails, ask the user for a fresh token rather than retrying.

**Deploy a directory:**
```bash
netlify deploy --prod --dir=/tmp/portfolio-v1-editorial
```

If the user wants a persistent "sandbox" site for concepts (not one-off previews), create a dedicated site once and reuse it:
```bash
# One-time: create a site for concept previews
netlify sites:create --name=concepts-preview
# Save the site ID for future deploys
netlify deploy --prod --dir=/tmp/concept --site=<site-id>
```

### Via Drag-and-Drop (Manual)

1. Zip the directory: `zip -r preview.zip /tmp/portfolio-v1-editorial/`
2. Go to `https://app.netlify.com/drop`
3. Upload the zip
4. Get instant URL

**Pitfall:** Netlify drag-and-drop deploys have 48-hour expiry unless linked to a site. For permanent previews, use `netlify deploy --prod` or connect to a Git repo.

## Multi-Preview Workflow (Parallel Design Directions)

When the user requests multiple visual directions (e.g., 3 design concepts), use sequential ports with clear labeling:

```bash
# Direction 1 — Editorial
python3 -m http.server 8001 --bind 0.0.0.0  # in /tmp/dir1

# Direction 2 — Technical
python3 -m http.server 8002 --bind 0.0.0.0  # in /tmp/dir2

# Direction 3 — Bold
python3 -m http.server 8003 --bind 0.0.0.0  # in /tmp/dir3
```

Then open each port and present all three URLs together.

**Cleanup before restart:** If re-deploying to the same ports, kill old processes first:
```bash
pkill -f "http.server"
# or more precisely:
kill $(ss -tlnp | grep ':800[123]' | awk '{print $7}' | cut -d',' -f2 | cut -d'=' -f2)
```

**Pitfall:** When serving multiple directories in parallel, don't use `nohup &` — use `terminal(background=true)` for each, then capture session IDs. Verify all three are listening with `ss -tlnp`.

## Common Pitfalls

| Symptom | Likely Cause | Fix |
|---------|-------------|-----|
| `curl: (7) Failed to connect` from external host | Binding to `127.0.0.1` | Use `--bind 0.0.0.0` |
| `curl: (7) Failed to connect` from VPS itself | Server not running | Check `ps aux \| grep http.server` |
| `curl` times out externally but works locally | Firewall blocking port | `ufw allow <port>/tcp` |
| 403 Forbidden | Directory has no index.html | Check `ls` in serve directory |
| Port already in use | Another process claimed it | `ss -tlnp \| grep <port>` |
| "not loading" from user's browser | ISP blocks port 8000+ | Switch to Netlify or Tailscale serve |

## Skill Integration

- **With subagent-driven-development:** When dispatching subagents to build visual mockups, include this skill's checklist in the parent agent's workflow. The parent should verify serve + firewall before declaring "done" to the user.
- **With claude-design / excalidraw:** After generating HTML design artifacts, use this skill to expose them for review.

## Remember

```
Bind to 0.0.0.0
Open the firewall
Verify with curl from the VPS
Give the user the public IP + port
If blocked, fall back to Tailscale or Netlify
```
