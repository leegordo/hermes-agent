---
name: signal-gateway-setup
description: "Set up Signal messenger as a messaging platform for Hermes Agent gateway via signal-cli HTTP daemon."
version: 1.0.0
author: Hermes Agent
platforms: [linux]
metadata:
  hermes:
    tags: [signal, messaging, gateway, signal-cli, setup]
    related_skills: [hermes-agent]
---

# Signal Gateway Setup for Hermes

Connect Hermes Agent to Signal messenger using signal-cli's HTTP daemon mode.

## Prerequisites

- **Java 25+** (OpenJDK 25) — signal-cli v0.14.4.1+ requires class file version 69. Java 21 will fail with `UnsupportedClassVersionError`.
- Network access to `chat.signal.org:443`

## Install signal-cli

```bash
# Install Java 25
apt-get install openjdk-25-jre-headless

# Download latest release
curl -fsSL -o /tmp/signal-cli.tar.gz \
  "https://github.com/AsamK/signal-cli/releases/download/v0.14.4.1/signal-cli-0.14.4.1.tar.gz"
tar xzf /tmp/signal-cli.tar.gz -C /opt/
ln -sf /opt/signal-cli-0.14.4.1/bin/signal-cli /usr/local/bin/signal-cli
```

## Link Device (Recommended)

Links signal-cli as a secondary device to an existing Signal account on a phone.

```bash
signal-cli link
# Outputs: sgnl://linkdevice?uuid=...&pub_key=...
```

**Critical:** The URI is valid for only ~2 minutes. Present it to the user **immediately**.

### QR Code Options

```bash
# Install qrencode
apt-get install qrencode

# PNG for web hosting
qrencode -s 10 -o /tmp/signal-qr.png "sgnl://linkdevice?..."

# ASCII for terminal (may not render in all terminals)
qrencode -t ansiutf8 "sgnl://linkdevice?..."
```

**Pitfall:** Online QR generators often reject custom protocol URIs (`sgnl://`). If the user cannot scan the QR, provide the raw `sgnl://` URI text and suggest they paste it into a desktop Signal client or use their phone's camera app directly.

## SMS Registration (Fallback)

If device linking fails, register signal-cli as a standalone primary device:

1. Get CAPTCHA token: visit `https://signalcaptchas.org/registration/generate.html`
2. Right-click "Open Signal" → copy link address
3. Extract the token from the `signalcaptcha://...` URI
4. Register:
   ```bash
   signal-cli -a +PHONE_NUMBER register --captcha TOKEN
   signal-cli -a +PHONE_NUMBER verify SMS_CODE
   ```

## TLS Certificate Fix

If `signal-cli link` outputs a URI then immediately fails with "Connection closed!", Signal's self-signed certificate may not be in Java's trust store:

```bash
openssl s_client -connect chat.signal.org:443 -servername chat.signal.org \
  </dev/null 2>/dev/null | openssl x509 -outform PEM > /tmp/signal-cert.pem

JAVA_CACERTS=$(find /usr -name "cacerts" | head -1)
keytool -import -trustcacerts -alias signal-messenger \
  -file /tmp/signal-cert.pem -keystore "$JAVA_CACERTS" \
  -storepass changeit -noprompt
```

## Start HTTP Daemon

```bash
signal-cli daemon --http 127.0.0.1:8080

# Verify
curl -fsSL http://127.0.0.1:8080/api/v1/check
# Expected: HTTP 200
```

The daemon holds the config file lock — CLI commands against the same data dir will fail with "Config file is in use" while the daemon runs.

## Hermes Configuration

Add to `~/.hermes/.env`:

```bash
SIGNAL_HTTP_URL=http://127.0.0.1:8080
SIGNAL_ACCOUNT=+LINKED_PHONE_NUMBER
SIGNAL_ALLOWED_USERS=+AUTHORIZED_SENDER_NUMBER
```

Restart gateway:
```bash
hermes gateway restart
```

Verify in logs:
```bash
grep -i "signal" /root/.hermes/logs/gateway.log | tail -5
```

## Troubleshooting

| Symptom | Cause | Fix |
|---------|-------|-----|
| `UnsupportedClassVersionError` | Java < 25 | Install `openjdk-25-jre-headless` |
| "Connection closed!" after URI | TLS cert rejected or link timed out | Import Signal CA cert; generate fresh link quickly |
| "Config file is in use" | Daemon running | Use HTTP API instead of CLI, or stop daemon first |
| "Invalid account" | Wrong `-a` format | Use full E.164: `+countrycode...` |
| "UNREGISTERED_FAILURE" | Recipient not on Signal | Verify recipient has active Signal account |
| `404 Not Found` on HTTP API | Wrong endpoint | Use `/api/v1/rpc` for JSON-RPC, not `/api/v1/messages` |
| "Specified account does not exist" | Multi-account mode mismatch | Omit `account` param if only one account linked |

## Workflow Preference

When a presentation approach (QR codes, web servers, image hosting) encounters repeated friction, **pivot early to simpler alternatives** rather than iterating on rendering workarounds. Users prefer a working text-based fallback over a theoretically elegant but practically broken visual solution.
