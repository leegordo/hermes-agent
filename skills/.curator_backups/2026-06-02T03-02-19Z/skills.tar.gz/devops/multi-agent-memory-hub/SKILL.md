---
name: multi-agent-memory-hub
description: "Set up and operate a MemPalace hub on a VPS as the always-on memory reconciler for multi-agent workflows. Covers installation, seeding, cross-machine sync testing, and troubleshooting."
version: 1.0.0
author: Hermes Agent
license: MIT
platforms: [linux]
metadata:
  hermes:
    tags: [mempalace, memory, sync, hub, vps, multi-agent]
    related_skills: [reconcile, hermes-agent, github-auth]
---

# Multi-Agent Memory Hub (MemPalace on VPS)

## Overview

When running multiple AI agents across machines (Macs with Claude Code, VPS with Hermes), they need shared memory. MemPalace provides vector-searchable memory drawers. The VPS acts as the **always-on hub** — it never sleeps, so it continuously ingests writes from all machines.

**Architecture:**
```
Mac A (Claude Code) → git commit → GitHub → VPS hub → mempalace search
Mac B (Claude Code) → git commit → GitHub → VPS hub → mempalace search
VPS (Hermes) ────────→ git pull ───────┘
```

## Prerequisites

- VPS running Hermes Agent (or any Linux with Python 3.11+)
- GitHub repo `multi-agent-memory` (or equivalent) with `memory/drawers/` directory
- `uv` installed (`curl -LsSf https://astral.sh/uv/install.sh | sh`)

## Phase 1: Install MemPalace on VPS

### Step 1: Clone the Memory Repo

```bash
mkdir -p ~/Projects
git clone https://github.com/<user>/multi-agent-memory.git ~/Projects/multi-agent-memory
```

If the repo is private, use a classic PAT (fine-grained PATs don't work for git operations):
```bash
git clone "https://<CLASSIC_PAT>@github.com/<user>/multi-agent-memory.git" ~/Projects/multi-agent-memory
```

### Step 2: Run Preflight

```bash
cd ~/Projects/multi-agent-memory
./scripts/preflight-vps.sh
```

Checks for: python3, git, uv, hermes, repo presence, git fetch access.

### Step 3: Install MemPalace

```bash
./scripts/install-mempalace-vps.sh
```

This:
- Installs `mempalace` and `mempalace-mcp` via uv
- Bootstraps an empty palace at `~/.mempalace/palace`
- Seeds drawers from `memory/drawers/`
- Wires MCP into `~/.hermes/config.yaml`

### Step 4: Bootstrap Hermes Integration

```bash
./scripts/bootstrap-hermes.sh
```

Links the reconcile skill to `~/.hermes/skills/` and sets up cron fallback.

### Step 5: Smoke Test

```bash
./scripts/smoke-mempalace-mcp.sh
```

Should report: `OK: found '<test-entity>' via mempalace search`

## Phase 2: Verify Cross-Machine Sync

### The Roundtrip Test

**On a Mac (Claude Code):**

1. Create a test drawer:
```bash
mkdir -p ~/Projects/multi-agent-memory/memory/drawers
cat > ~/Projects/multi-agent-memory/memory/drawers/test_vps_roundtrip_$(date +%Y%m%d).md << 'EOF'
# VPS Roundtrip Test

Written from: MacBook
Timestamp: $(date -u +%Y-%m-%dT%H:%M:%SZ)

This is a cross-machine memory test. If this drawer appears in the
MemPalace on the VPS Hermes agent, the git-as-bus sync is working.

Test content: <unique-verification-phrase>
EOF
```

2. Sync it:
```bash
cd ~/Projects/multi-agent-memory && ./scripts/sync.sh
```

**Pitfall — GitHub email privacy (GH007):**
If push fails with `GH007: Your push would publish a private email address`, the commit was made with a private email. Fix:
```bash
git config --global user.email "<username>@users.noreply.github.com"
git commit --amend --reset-author --no-edit
./scripts/sync.sh
```

**On the VPS (Hermes):**

3. Pull and seed:
```bash
cd ~/Projects/multi-agent-memory
git pull origin main
python3 scripts/seed-mempalace.py
```

4. Verify:
```bash
mempalace search "<unique-verification-phrase>"
```

Should find the drawer with the MacBook timestamp.

## Phase 3: Daily Operations

### Search the Palace

```bash
# Search for anything
mempalace search "cross machine sync"

# Get wake-up context (~600-900 tokens)
mempalace wake-up

# Check health
mempalace status
```

### Manual Hub Sync

```bash
cd ~/Projects/multi-agent-memory
./scripts/hub-sync.sh
```

Pulls latest from GitHub, seeds new drawers, resolves conflicts.

### Scheduled Sync (Cron)

If systemd user session is unavailable (common on VPS), use cron:

```bash
# Edit crontab
crontab -e

# Add: sync every 15 minutes
*/15 * * * * cd ~/Projects/multi-agent-memory && ./scripts/hub-sync.sh >> /tmp/hub-sync.log 2>&1
```

## Troubleshooting

| Symptom | Cause | Fix |
|---------|-------|-----|
| `mempalace search` returns nothing new | Palace not re-seeded after git pull | Run `python3 scripts/seed-mempalace.py` |
| `git pull` fails with auth | Token in remote URL is invalid or expired | Update token: `git remote set-url origin https://<TOKEN>@github.com/...` |
| `GH007` on push | Git commit uses private email | Amend with noreply email |
| `smoke-mempalace-mcp.sh` fails | MCP not wired in Hermes config | Re-run `./scripts/install-mempalace-vps.sh` |
| Fine-grained PAT fails git clone | GitHub disabled password auth for git ops | Use classic PAT or SSH deploy key |
| Shell escapes token with underscores | Bash word-splitting on `ghp_...` | Use Python/urllib for API calls instead of curl |

## Key Principles

1. **VPS is the source of truth** — it never sleeps, always has the latest reconciled memory
2. **Git is the bus** — GitHub is the canonical transport, not a direct VPS-to-Mac connection
3. **Seed after every pull** — `git pull` doesn't auto-update the palace; always re-seed
4. **Classic PAT for git, fine-grained for API** — Fine-grained PATs work for REST API but not `git clone`/`git push`
5. **Test the roundtrip** — Create a drawer on Mac, sync, search on VPS. If it works, the pipeline works
