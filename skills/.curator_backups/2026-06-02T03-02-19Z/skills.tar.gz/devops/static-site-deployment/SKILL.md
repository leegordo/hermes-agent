---
name: static-site-deployment
description: "Deploy static HTML/CSS/JS sites to Netlify with GitHub source control. Full workflow from build to live URL."
version: 1.0.0
author: Hermes Agent
license: MIT
platforms: [linux, macos]
metadata:
  hermes:
    tags: [Netlify, GitHub, Static Sites, Deployment, CLI, Prototyping]
    related_skills: [github-repo-management, remote-static-preview, portfolio-website-redesign]
---

# Static Site Deployment

Deploy static HTML/CSS/JS sites to Netlify with GitHub as the source-of-truth. This is the standard workflow for creative prototypes, landing pages, concept demos, and portfolio pieces.

## When to Use

- User asks for a "landing page", "demo", "prototype", or "concept"
- User says "deploy this" or "host this somewhere"
- User wants "a place to deploy concepts"
- Any static HTML/CSS/JS output that needs a live URL

**Default target:** For this user, GitHub Pages (leegordo.github.io/<repo>) is the default for creative work and portfolio pieces. Netlify is fallback only if the Netlify CLI + token are already working. VPS static preview is last resort.

## Prerequisites

- `git` configured with identity (see `github-auth` skill)
- `gh` CLI authenticated (see `github-auth` skill)
- For Netlify: Node.js/npm available (for Netlify CLI install)

---

## Target A: GitHub Pages (Default)

GitHub Pages is free, fast, and keeps everything in one place (GitHub). Best for portfolios, concept demos, and static creative work.

### Step 1: Build the Site

Create the static files in a dedicated directory under `~/Projects/`:

```bash
mkdir -p ~/Projects/<project-name>
# Write index.html, assets, etc.
```

For single-page creative landers, a single `index.html` with embedded CSS/JS is often enough. For multi-page sites, use a directory structure with `index.html` at the root.

### Step 2: Initialize Git and Push to GitHub

```bash
cd ~/Projects/<project-name>
git init
git add .
git commit -m "feat: initial site"
git branch -m main

# Create public repo and push
gh repo create <repo-name> --public --source=. --push
```

**Naming:** Use short descriptive names. The live URL will be `https://leegordo.github.io/<repo-name>/`.

### Step 3: Enable GitHub Pages

```bash
# Enable Pages on the main branch, root directory
gh api repos/leegordo/<repo-name>/pages \
  -X POST \
  -f source='{"branch":"main","path":"/"}' 2>/dev/null || \
gh api repos/leegordo/<repo-name>/pages \
  -H "Accept: application/vnd.github+json" \
  -X PUT \
  -f source='{"branch":"main","path":"/"}'
```

Or enable manually: **https://github.com/leegordo/<repo-name>/settings/pages** → Source: Deploy from a branch → `main` / `/(root)`.

### Step 4: Verify the Live URL

```bash
# Check Pages status
gh api repos/leegordo/<repo-name>/pages --jq '.html_url, .status'
```

Live URL will be: `https://leegordo.github.io/<repo-name>/`

Allow 30-60 seconds for the first build. If the repo existed before with different content, force-push or clear the Pages cache by making a new commit.

### Step 5: Subsequent Deploys

After initial setup, redeploying is just:

```bash
cd ~/Projects/<project-name>
git add . && git commit -m "update: ..." && git push
```

GitHub Pages rebuilds automatically on push.

---

## Target B: Netlify (Fallback)

Use Netlify when you need branch deploys, form handling, edge functions, or when GitHub Pages constraints (no server-side logic, 1GB soft limit) are too restrictive.

### Step 1: Build the Site

Same as GitHub Pages Step 1 above.

### Step 2: Initialize Git and Push to GitHub

Same as GitHub Pages Step 2 above. Netlify can deploy from a GitHub repo.

### Step 3: Install Netlify CLI

```bash
# Check if already installed
netlify --version

# Install if missing — USE FOREGROUND with long timeout
# Background install with notify_on_complete fails silently for this package
npm install -g netlify-cli
```

**Pitfall:** Do NOT use `terminal(background=true, notify_on_complete=true)` for Netlify CLI install. The background process produces no output and times out. Use foreground with `timeout=300`.

### Step 4: Authenticate Netlify

On headless servers, the browser login flow (`netlify login`) does not work. Use a Personal Access Token (PAT):

```bash
# User provides their Netlify PAT (nfp_...)
export NETLIFY_AUTH_TOKEN="<pat-here>"
netlify status
```

**Security:** Do NOT write the PAT into commands for the user to run. The user's security tooling blocks credential-containing terminal commands. Instead, tell the user:

> Run this with your PAT:
> ```
> export NETLIFY_AUTH_TOKEN="your_pat_here"
> netlify status
> ```

### Step 5: Link and Deploy

```bash
cd ~/Projects/<project-name>

# Link to a Netlify site (creates new or links existing)
netlify link

# Deploy to production
netlify deploy --prod --dir=.
```

For first deploys, `netlify link` will ask to create a new site. Accept the defaults. The deploy command outputs the live URL.

### Step 6: Subsequent Deploys

After the initial setup, redeploying is just:

```bash
cd ~/Projects/<project-name>
git add . && git commit -m "update: ..." && git push
netlify deploy --prod --dir=.
```

## Verification Checklist

- [ ] GitHub repo exists and `main` branch is pushed
- [ ] `netlify status` shows authenticated
- [ ] `netlify deploy --prod` outputs a live URL
- [ ] URL loads in browser without 404

## Troubleshooting

| Problem | Solution |
|---------|----------|
| `npm install -g netlify-cli` hangs | Use foreground with `timeout=300`. Background install fails silently. |
| `netlify login` fails on server | Expected. Use `NETLIFY_AUTH_TOKEN` env var instead. |
| `netlify status` says "Not logged in" | Token not exported or invalid. Re-export `NETLIFY_AUTH_TOKEN`. |
| Deploy succeeds but site 404s | Check `--dir=.` points to the directory containing `index.html`. |
| `gh repo create` fails | Check `gh auth status`. May need to re-auth. |

## Related

- `github-auth` — GitHub authentication setup
- `github-repo-management` — Repo creation, remotes, releases
- `remote-static-preview` — Serve static files from the VPS directly (alternative to Netlify)
