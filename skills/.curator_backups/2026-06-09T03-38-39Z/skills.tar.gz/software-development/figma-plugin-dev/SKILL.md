---
name: figma-plugin-dev
title: Figma Plugin Development
description: Build, debug, and ship Figma plugins. Covers manifest.json validation, CORS/networkAccess config, UI-to-plugin-code message passing, and common conversion tasks (CSS → Figma nodes).
trigger: building figma plugins, figma manifest errors, figma plugin network access, figma dev mode, figma to canvas, figma bridge, figma 'Manifest error'
toolsets:
  - terminal
  - file
---

# Figma Plugin Development

## Quick checks for manifest errors

Figma's manifest validator is strict and error messages can chain — fix one and another appears. Work top to bottom:

1. **Schema check**: Must be valid JSON. No trailing commas.
2. **`editorType`**: Must include `"figma"` for design mode. Must ALSO include `"dev"` for Dev Mode. Typical: `["figma", "dev"]`.
3. **`networkAccess.reasoning`**: Required if `allowedDomains` contains `"*"` (wildcard). Write a brief justification of why the plugin needs open domains.
4. **`networkAccess.devAllowedDomains`**: Must be **full URLs**, not bare hostnames. **No IP addresses** (`127.0.0.1` rejected even with protocol). **Do not use port wildcards** (`localhost:*` is invalid).

| Wrong | Right |
|---|---|
| `"localhost:*"` | `"http://localhost"` |
| `"127.0.0.1"` | `"http://localhost"` (drop IP entirely) |
| `"leegordo.github.io"` | `"https://leegordo.github.io"` |
| Missing `reasoning` | Add `reasoning` string |
| Only `"figma"` in `editorType` | Add `"dev"` if using Dev Mode |

## Plugin code ↔ UI message passing

- UI (`ui.html`) sends: `parent.postMessage({ pluginMessage: { type: '...', ... } }, '*')`
- Plugin code (`code.js`) receives: `figma.ui.onmessage = async (msg) => { ... }`
- Plugin sends back: `figma.ui.postMessage({ type: 'success', message: '...' })`
- UI receives: `window.onmessage = (event) => { const msg = event.data.pluginMessage; ... }`

## CORS / fetch behavior

- `allowedDomains: ["*"]` opens all domains but requires `reasoning`.
- Plugin sandbox runs `fetch()` like a normal browser.
- If `fetch` fails, verify the URL is reachable from the plugin's network context (not the user's browser).

## CSS → Figma conversion map

| CSS | Figma Property |
|---|---|
| `backgroundColor` | `fills` (SOLID) |
| `linear-gradient()` / `radial-gradient()` | `fills` (GRADIENT_LINEAR / GRADIENT_RADIAL) |
| `border` | `strokes` + `strokeWeight` + `strokeAlign` |
| `border-radius` | `cornerRadius` |
| `box-shadow` | `effects` array (DROP_SHADOW) |
| `opacity` | `opacity` |
| `display: flex` | `layoutMode: "HORIZONTAL"/"VERTICAL"` |
| `gap` / `row-gap` | `itemSpacing` |
| `padding-*` | `paddingTop`, `paddingRight`, etc. |

## Common node type fallbacks

- Unsupported or generic container → `figma.createFrame()`
- Image/SVG with no fill → `figma.createRectangle()` (or IMAGE node with actual image fill)
- Text-only leaf with no block children → `figma.createText()`

## Font loading

Always `await figma.loadFontAsync(fontName)` before setting text properties that reference that font. Catch and fall back to `Inter Regular`.

## References

- `references/manifest-validation-trail.md` — Full transcript of a real 4-error validation chain and fixes applied.
