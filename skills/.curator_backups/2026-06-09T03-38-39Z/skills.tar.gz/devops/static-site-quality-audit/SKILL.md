---
name: static-site-quality-audit
description: Systematic quality checks for static HTML/CSS sites — link integrity, nav consistency, responsive design, asset loading, and content freshness across all pages including subdirectories.
version: 1.0.0
author: Hermes Agent
license: MIT
platforms: [linux, macos, windows]
metadata:
  hermes:
    tags: [static-site, quality, audit, html, css, responsive, mobile]
    related_skills: [claude-design, static-site-deployment]
---

# Static Site Quality Audit

A systematic pass over every page of a static site to catch broken links, stale content, inconsistent navigation, and mobile layout issues. Run this after any refactor that touches nav, structure, or shared components.

## When to use this skill

- After removing/renaming sections (e.g. stripping Factory & Portal from nav)
- After adding new page types (blog posts, gallery items, idea briefs)
- Before deploying a redesign or restructure
- When user reports "something looks broken on mobile"
- After any CSS change to shared styles (especially `@media` queries)

## Trigger conditions

Any of these should prompt a full audit, not just the page you edited:
- Nav structure changed (items added/removed/reordered)
- Footer text or layout changed
- Shared CSS file modified
- New subdirectory of pages added (blog posts, gallery systems, etc.)
- Domain or base path changed (e.g. root site → GitHub Pages project site)

## Audit checklist

### 1. Link integrity ( Critical )

**Check every internal link on every page.** Sub-pages are the #1 source of stale links.

```bash
# Find all HTML files
cd <project-root>
find . -name "*.html" | sort

# Check for stale section references
grep -rl "factory/\|portal/\|old-section/" --include="*.html" .

# Check for root-relative links that break on GitHub Pages
grep -rl 'href="/"' --include="*.html" .
```

**Common break patterns:**
- `href="/"` on GitHub Pages project sites → use `href="./"` or relative path
- `../factory/` still referenced after section deleted
- Blog posts linking to old nav items
- Gallery system pages with outdated "Use This System" text

### 2. Navigation consistency ( Critical )

Every page MUST have the same nav items in the same order. No exceptions for sub-pages.

```bash
# Extract nav from every page and diff
grep -A5 '<nav>' blog/posts/*.html committee/*.html gallery/*.html
```

**Pitfall:** Blog posts, gallery detail pages, and committee idea briefs often have hand-coded nav that doesn't get updated when the main nav changes. Always check these.

### 3. Footer consistency ( Medium )

```bash
# Find stale footer text
grep -rl "old footer text" --include="*.html" .
```

### 4. Asset loading ( Critical )

```bash
# Check CSS links are correct for each directory level
grep -r "0xcreative.css" --include="*.html" .
# Root pages: assets/css/0xcreative.css
# One level deep: ../assets/css/0xcreative.css
# Two levels deep: ../../assets/css/0xcreative.css
```

### 5. Viewport meta tag ( Critical for mobile )

Every page MUST have:
```html
<meta name="viewport" content="width=device-width, initial-scale=1.0">
```

```bash
grep -L "viewport" --include="*.html" -r .
# -L = files that DON'T match
```

### 6. Mobile responsive ( Medium )

**Test at 375px (iPhone SE) and 768px (iPad).**

Checklist:
- [ ] No horizontal overflow (no `overflow-x: scroll` on body)
- [ ] Nav fits or wraps gracefully (no overlapping items)
- [ ] Hero text scales with `clamp()` — not fixed large sizes
- [ ] CTAs stack vertically, full-width
- [ ] Cards go single-column
- [ ] Grid layouts collapse gracefully
- [ ] Touch targets ≥ 44px tall
- [ ] Font sizes ≥ 14px for body text
- [ ] Padding comfortable but not excessive (16px sides, not 40px)
- [ ] Code blocks don't overflow viewport

**Common mobile CSS fixes:**
```css
@media (max-width: 768px) {
  nav { padding: 12px 16px; flex-wrap: wrap; }
  .container { padding: 0 1rem; }
  .page-content { padding-top: 80px; }
  .hero { padding: 6rem 1rem 3rem; min-height: auto; }
  .hero-cta { flex-direction: column; width: 100%; }
  .hero-cta .btn { width: 100%; justify-content: center; }
  .card-grid { grid-template-columns: 1fr; gap: 1rem; }
  h1 { font-size: clamp(2rem, 8vw, 3rem); }
  h2 { font-size: clamp(1.25rem, 5vw, 1.75rem); }
  .section-header { flex-direction: column; align-items: flex-start; }
  pre { padding: 0.75rem; font-size: 0.8rem; }
}
```

### 7. Content freshness ( Low )

- No "Coming Soon" on shipped features
- No placeholder text (Lorem ipsum, "TODO", etc.)
- Dates and version numbers are current

## Verification commands

```bash
# After fixes, verify nothing stale remains
grep -rl "OLD_TEXT" --include="*.html" . || echo "Clean"

# Count HTML files (should match pages checked)
find . -name "*.html" | wc -l

# Quick build check (if using a build step)
# npm run build || bundle exec jekyll build || echo "No build step"
```

## Pitfalls

1. **Sub-pages are invisible until you look.** Blog posts, gallery systems, idea briefs — these are the first to break during refactors because they're not in the main nav file.
2. **GitHub Pages project sites break root-relative links.** `href="/"` goes to `username.github.io/`, not `username.github.io/repo/`. Always use relative paths (`./`, `../`) for project sites.
3. **CSS `@media` blocks are often too minimal.** A 5-line mobile breakpoint is almost always insufficient. Plan for 50+ lines covering nav, hero, grids, cards, buttons, and typography.
4. **Viewport meta tag is easy to forget on new pages.** Use `grep -L` to find pages missing it.
5. **Footer text is copy-pasted, not included.** When you change the footer in one place, grep for the old text across all HTML files.

## Related

- `static-site-deployment` — for deploying after audit passes
- `claude-design` — for building the pages that then need auditing
