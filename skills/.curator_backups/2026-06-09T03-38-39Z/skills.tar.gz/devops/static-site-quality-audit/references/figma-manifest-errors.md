# Figma Plugin Manifest — Common Errors & Fixes

Session: 2026-06-02 — DoodleHaus Bridge plugin manifest fixes

## Error: "Invalid value for networkAccess. If you want to allow all domains, please add a 'reasoning' field"

**Cause:** `networkAccess.allowedDomains` contains `"*"` but missing `reasoning` field.

**Fix:**
```json
"networkAccess": {
  "allowedDomains": ["*"],
  "devAllowedDomains": ["http://localhost", "https://example.com"],
  "reasoning": "The plugin fetches design JSON from external URLs and loads image assets."
}
```

## Error: "Invalid value for devAllowedDomains. 'localhost:*' must be a valid URL"

**Cause:** Wildcard ports (`localhost:*`) are not valid URLs.

**Fix:** Use protocol + host without port wildcard:
```json
"devAllowedDomains": [
  "http://localhost",
  "https://leegordo.github.io"
]
```

**Note:** `http://localhost` without a port covers all localhost ports in Figma's network model.

## Error: "Invalid value for devAllowedDomains. 'http://127.0.0.1' must be a valid URL"

**Cause:** Figma rejects IP addresses in `devAllowedDomains`.

**Fix:** Use `http://localhost` instead. It covers the same ground and passes validation.

## Error: "The manifest editorType does not include 'dev'"

**Cause:** Plugin loaded in Figma Dev Mode but manifest only has `"figma"` in `editorType`.

**Fix:**
```json
"editorType": ["figma", "dev"]
```

## Working manifest template

```json
{
  "name": "DoodleHaus Bridge",
  "id": "doodlehaus-bridge",
  "api": "1.0.0",
  "main": "code.js",
  "ui": "ui.html",
  "editorType": ["figma", "dev"],
  "networkAccess": {
    "allowedDomains": ["*"],
    "devAllowedDomains": ["http://localhost", "https://example.com"],
    "reasoning": "The plugin fetches design JSON from external URLs and loads image assets referenced in generated designs."
  }
}
```

## Key rules

| Field | Rule |
|-------|------|
| `allowedDomains: ["*"]` | Requires `reasoning` field |
| `devAllowedDomains` | Must be valid URLs (protocol + host). No wildcards. No IPs. |
| `editorType` | Add `"dev"` if users open plugin in Dev Mode |
| `reasoning` | 1-2 sentences explaining why network access is needed |
